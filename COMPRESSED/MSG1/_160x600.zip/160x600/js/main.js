var banner={},B=banner
window.onload=function(){B.init()},B.borderColor="#000000",B.hideReloadOnBubbleOpen=!1,B.tOrigin="151px 173px",B.legalBubble=!0,B.init=function(){var n=["bubble"],e={x:0,y:0,atlas:!0,dimensions:{w:90,h:22}},i={x:0,y:0,scale:.5,transformOrigin:"18px 18px",reverse:!0,hardRefresh:!0}
Main.init(null,null,n,e,"",i,null,null),B.prelim(),F.HDify(["bubble","back"])},B.prelim=function(){!1===B.prelimDone&&B.setUpDivs(),B.prelimDone=!0},B.animate=function(){A.visible(["back"]),B.addScrollableLegal(!1)}
